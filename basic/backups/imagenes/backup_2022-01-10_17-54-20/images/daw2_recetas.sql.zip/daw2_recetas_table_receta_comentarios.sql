
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `receta_comentarios`
--

CREATE TABLE IF NOT EXISTS `receta_comentarios` (
  `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `receta_id` int(12) UNSIGNED NOT NULL,
  `usuario_id` int(12) UNSIGNED NOT NULL COMMENT 'Usuario que ha creado el comentario. No deberia ser CERO (como si fuera NULL).',
  `fechahora` datetime NOT NULL,
  `texto` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `receta_comentarios`
--

TRUNCATE TABLE `receta_comentarios`;
--
-- Volcado de datos para la tabla `receta_comentarios`
--

INSERT INTO `receta_comentarios` (`id`, `receta_id`, `usuario_id`, `fechahora`, `texto`) VALUES
(1, 11, 2, '2022-01-07 00:10:09', 'excelente receta, a mis hijos les encanta'),
(2, 12, 1, '2022-01-07 00:10:42', 'Una, buena fabada asturiana 100%, como tiene que ser'),
(3, 13, 6, '2022-01-07 00:11:51', 'Lo hice para mi sólo pero da para comer una legión. Lo tuve que dejar para desayunarlo al día siguiente :)'),
(4, 14, 5, '2022-01-07 00:12:30', 'Me encanta pero el médico me ha dicho que me cuide con el azúcar'),
(5, 15, 8, '2022-01-07 00:13:53', 'Una tortilla con cebolla y una cerveza para pasarla mejor. Como Dios manda!!'),
(6, 16, 3, '2022-01-07 00:14:30', 'Es pan, a quién no le gusta?'),
(7, 17, 4, '2022-01-07 00:15:11', 'Iguales que los de mi abuela me han salido'),
(8, 12, 7, '2022-01-07 00:15:34', 'Con fabes y sidrina...'),
(9, 11, 8, '2022-01-07 00:16:26', 'receta superfácil');
