
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL COMMENT 'Correo Electronico y "login" del usuario.',
  `password` varchar(60) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `rol` char(1) NOT NULL COMMENT 'Tipo de Perfil: C=Colaborador, A=Administrador, T=Tienda.',
  `aceptado` tinyint(1) NOT NULL COMMENT 'Indicador de usuario aceptado su registro o no.',
  `creado` datetime NOT NULL COMMENT 'Fecha y Hora de creacion del usuario',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `usuarios`
--

TRUNCATE TABLE `usuarios`;
--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `email`, `password`, `nombre`, `rol`, `aceptado`, `creado`) VALUES
(1, 'fer@gmail.com', 'cef48cb4569d34364e0e86067efa14fbe9b4591e', 'fer', 'A', 1, '2022-01-03 15:57:24'),
(2, 'marcos@gmail.com', 'dfadc855249b015fd2bb015c0b099b2189c58748', 'marcos', 'A', 1, '2022-01-06 21:20:26'),
(3, 'victor@gmail.com', '88fa846e5f8aa198848be76e1abdcb7d7a42d292', 'victor', 'A', 1, '2022-01-06 21:21:25'),
(4, 'nerea@gmail.com', 'ecd38c3624dcb1ab55b8a926a44d3dbeeed84fc6', 'nerea', 'A', 1, '2022-01-06 21:21:54'),
(5, 'pablo@gmail.com', '707d14912bb250caf67dfe0ea4035681fbfc4f56', 'pablo', 'A', 1, '2022-01-06 21:22:38'),
(6, 'manu@gmail.com', '158873d90a7ef40f3637a222b7329c09d0222554', 'manu', 'A', 1, '2022-01-06 21:23:51'),
(7, 'sara@gmail.com', 'dea04453c249149b5fc772d9528fe61afaf7441c', 'sara', 'A', 1, '2022-01-06 21:24:27'),
(8, 'elsa@gmail.com', '431651dd2bf464e7ef8821b265af8119e4e25b63', 'elsa', 'A', 1, '2022-01-06 21:24:48'),
(9, 'colaborador@gmail.com', 'cd6a0dd2dfac024a049e7430ab284075befe8e91', 'colaborador', 'C', 1, '2022-01-06 21:25:18'),
(10, 'tienda@gmail.com', '58637696377734903ceb69effb9b48e3d058bf4e', 'tienda', 'T', 1, '2022-01-06 21:25:42'),
(11, 'sistema@gmail.com', '2bd603bdfc39c0015d0d9f3194bb84fb18ed708c', 'sistema', 'S', 1, '2022-01-06 21:26:38');
