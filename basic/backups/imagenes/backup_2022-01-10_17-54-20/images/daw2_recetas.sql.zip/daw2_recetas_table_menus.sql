
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `titulo` text NOT NULL,
  `descripcion` text NOT NULL,
  `usuario_id` int(12) UNSIGNED DEFAULT NULL COMMENT 'Usuario que ha creado el menu o CERO si no existe (como si fuera NULL).',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `menus`
--

TRUNCATE TABLE `menus`;
--
-- Volcado de datos para la tabla `menus`
--

INSERT INTO `menus` (`id`, `titulo`, `descripcion`, `usuario_id`) VALUES
(9, 'Menu Asturiano', 'La gastronomía de Asturias es el conjunto de tradiciones culinarias, ingredientes y recetas propio del Principado de Asturias (España). Si bien es cierto que la cocina asturiana ha sabido transmitirse generación tras generación, también lo es que carece de tradición escrita hasta época muy reciente, ya que no existen apenas escritos que muestren qué comían los asturianos, y los pocos relatos que se conservan se encuentran en textos de naturaleza muy distinta a la gastronómica. ', 1),
(10, 'Menu vegano', 'El veganismo, del inglés veganism,​ es la abstención del uso de productos de origen animal.', 3),
(11, 'Menu iberico', 'La gastronomía o cocina española son los platos, ingredientes, técnicas y toda la tradición culinaria que se practica en España. Cocina de origen que oscila entre el estilo rural y el costero, representa una diversidad fruto de muchas culturas, así como de paisajes y climas.', 2),
(12, 'Menu andaluz', 'La comunidad autónoma de Andalucía posee una rica gastronomía propia, muy variada y con diferencias entre la costa y el interior. Forma parte de la dieta mediterránea. Consiste en una gastronomía muy vinculada al uso del aceite de oliva, los frutos secos, los pescados y las carnes.', 5),
(13, 'Menu carnivoro', 'La dieta carnívora significa obtener nutrición de alimentos de origen animal y limitar o eliminar severamente todas las plantas de la dieta. El propósito de esta forma de comer es mejorar la salud, perder grasa, curar el cuerpo y la mente y aliviar muchas enfermedades crónicas.', 7),
(14, 'Menu Capitan', 'Permite comer de todo, no hay restricciones. Además de todo lo que considera una dieta vegana, también incluye los alimentos que no se permite consumir en la anteriormente mencionada: todos los tipos de carne, pescado, marisco, lácteos y huevos.', 6),
(15, 'Menu de autor', 'La cocina de autor es una perfecta representación de tendencia gastronómica. Esta tipología  de cocina, tan celebrada y curiosa, se basa en la creación de platos en base a la creatividad y experiencia del chef. Es decir, el chef como autor de una obra, que en este caso es un plato. Es una cocina que manifiesta grandes rasgos de personalidad e innovación, y donde el sello de identidad juega un papel crucial.', 8);
