
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tiendas`
--

CREATE TABLE IF NOT EXISTS `tiendas` (
  `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `domicilio` varchar(150) DEFAULT NULL,
  `poblacion` varchar(50) DEFAULT NULL,
  `provincia` varchar(50) DEFAULT NULL,
  `usuario_id` int(12) UNSIGNED NOT NULL COMMENT 'Usuario que se corresponde con la tienda para poder conectar a la aplicación web.',
  `activa` tinyint(1) NOT NULL COMMENT 'Si la tienda esta activa para conectar como usuario, y si estará visible desde el portal junto con sus ofertas independientemente de que esté visible o no.',
  `visible` tinyint(1) NOT NULL COMMENT 'Si la tienda y sus ofertas estarán visibles en el portal aunque esté la tienda activa.',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `tiendas`
--

TRUNCATE TABLE `tiendas`;
--
-- Volcado de datos para la tabla `tiendas`
--

INSERT INTO `tiendas` (`id`, `nombre`, `domicilio`, `poblacion`, `provincia`, `usuario_id`, `activa`, `visible`) VALUES
(2, 'Mercadona', 'Calle Monsalve, 2', 'Zamora', 'Zamora', 10, 1, 1),
(3, 'Alimerka', 'Calle Ramón del Valle, 11', 'Arriondas', 'Asturias', 10, 1, 1),
(4, 'Lidl', 'Av. Padre Ignacio Ellacuría, 1', 'Salamanca', 'Salamanca', 10, 1, 1),
(5, 'Carrefour Express', 'Calle Arzobispo Guisasola, 42', 'Oviedo', 'Asturias', 10, 1, 1),
(6, 'Eroski', 'C. Epifanía, 6', 'Valladolid', 'Valladolid', 10, 1, 1),
(7, 'Dia', 'C. de la Virgen de los Peligros, 9', 'Madrid', 'Madrid', 10, 1, 1),
(8, 'Coviran', 'Av. Portugal, 1', 'Cádiz', 'Cádiz', 10, 1, 1);
