
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tienda_ofertas`
--

CREATE TABLE IF NOT EXISTS `tienda_ofertas` (
  `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tienda_id` int(12) UNSIGNED NOT NULL,
  `ingrediente_id` int(12) UNSIGNED NOT NULL,
  `descripcion` text DEFAULT NULL,
  `envase` text DEFAULT NULL,
  `cantidad` float NOT NULL DEFAULT 0,
  `medida` varchar(45) DEFAULT NULL,
  `notas` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `tienda_ofertas`
--

TRUNCATE TABLE `tienda_ofertas`;
--
-- Volcado de datos para la tabla `tienda_ofertas`
--

INSERT INTO `tienda_ofertas` (`id`, `tienda_id`, `ingrediente_id`, `descripcion`, `envase`, `cantidad`, `medida`, `notas`) VALUES
(1, 2, 1, '10% dto.', 'pack de 3 chorizos', 300, 'g', 'solo aplicable una vez'),
(2, 6, 1, '2x1', 'chorizos sueltos', 200, 'g', 'llevas 2 y pagas 1'),
(3, 3, 11, '15 % en la segunda unidad', 'queso entero', 450, 'g', 'solo hasta el 12/01/2021'),
(4, 5, 23, 'sólo 3,99 €', 'malla de cebollas', 1, 'kg', 'sólo hasta el 01/02/2021'),
(5, 4, 19, 'sólo 0,59 €', 'paquete', 1, 'kg', 'sólo hasta el 21/01/2022'),
(6, 7, 10, '3x2', 'botella', 1, 'L', 'sólo el 13/01/2022'),
(7, 8, 22, 'gratis la 2ª unidad', 'bolsa', 500, 'g', 'sólo los martes'),
(8, 8, 22, '40% en la segunda unidad', 'bandeja 4 tomates', 300, 'g', '---'),
(9, 2, 13, '3x2', 'huevera', 1, 'docena', '---'),
(10, 2, 18, 'sólo 0,78 €', 'tetrabrick', 1, 'L', '---'),
(11, 2, 3, 'OFERTA ESPECIAL - 9,90 €', 'a granel', 1, 'kg', 'Oferta sólo válida para socios Mercadona'),
(12, 2, 16, 'OFERTA ESPECIAL - 3,50 €', 'bolsa', 5, 'kg', '---'),
(13, 2, 7, 'OFERTA DEL DÍA - 0,32 €', 'paquete', 1, 'kg', 'Sólo válida el 11/01/2022'),
(14, 2, 17, '2x1', 'paquete', 1, 'kg', '---');
