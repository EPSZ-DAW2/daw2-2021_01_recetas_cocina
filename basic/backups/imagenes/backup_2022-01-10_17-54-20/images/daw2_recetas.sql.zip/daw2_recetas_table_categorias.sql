
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `categoria_padre_id` int(12) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Identificador de la categoria padre en caso de estar ordenados por jerarquías.',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `categorias`
--

TRUNCATE TABLE `categorias`;
--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`, `descripcion`, `categoria_padre_id`) VALUES
(1, 'Vegano', 'Nada procede de origen animal', 0),
(2, 'Carnivoro', 'La carne es lo principal', 0),
(3, 'Mediterráneo', 'La dieta mediterránea es el modo de alimentarse basado en la cocina tradicional de la cuenca mediterránea.', 0),
(4, 'Ibérico', 'Tanto en España como en Portugal predominan los productos del mar, los pescados y los mariscos, y también damos la máxima importancia al mundo vegetal, las frutas y las verduras. Y, por supuesto, al aceite de oliva virgen extra. Destaca también la oferta enoturística.', 3),
(5, 'Light', 'Se denomina alimento light o ligero aquel cuyo valor energético supone una reducción de al menos un 30% del producto originario de referencia. Habitualmente, los alimentos light tienen bajos niveles de calorías porque son desgrasados o se les reduce o anula la cantidad de azúcares.', 0),
(6, 'Fitness', 'Lo mejor para ponerte a tono de cara al verano.', 0);
