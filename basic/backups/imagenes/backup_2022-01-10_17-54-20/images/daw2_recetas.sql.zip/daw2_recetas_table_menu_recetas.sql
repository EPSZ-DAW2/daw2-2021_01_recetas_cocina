
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu_recetas`
--

CREATE TABLE IF NOT EXISTS `menu_recetas` (
  `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `menu_id` int(12) UNSIGNED NOT NULL,
  `receta_id` int(12) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `menu_recetas`
--

TRUNCATE TABLE `menu_recetas`;
--
-- Volcado de datos para la tabla `menu_recetas`
--

INSERT INTO `menu_recetas` (`id`, `menu_id`, `receta_id`) VALUES
(20, 9, 12),
(21, 9, 13),
(22, 9, 16),
(23, 10, 11),
(24, 10, 16),
(26, 11, 12),
(27, 11, 11),
(28, 11, 13),
(29, 11, 15),
(30, 11, 16),
(31, 11, 17),
(32, 9, 14),
(33, 12, 11),
(34, 13, 13),
(35, 14, 15),
(36, 14, 16),
(37, 15, 12),
(38, 12, 16),
(39, 13, 16),
(40, 15, 16);
