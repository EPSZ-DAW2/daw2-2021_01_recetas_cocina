
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planificacion_menus`
--

CREATE TABLE IF NOT EXISTS `planificacion_menus` (
  `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `planificacion_id` int(12) UNSIGNED NOT NULL,
  `menu_id` int(12) UNSIGNED NOT NULL COMMENT 'Menu relacionado con el dia planificado',
  `numero_dia` smallint(3) NOT NULL COMMENT 'Numero de dia del menu dentro de la planificacion.',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `planificacion_menus`
--

TRUNCATE TABLE `planificacion_menus`;
--
-- Volcado de datos para la tabla `planificacion_menus`
--

INSERT INTO `planificacion_menus` (`id`, `planificacion_id`, `menu_id`, `numero_dia`) VALUES
(12, 8, 9, 1),
(13, 8, 10, 2),
(14, 8, 11, 3),
(15, 8, 12, 4),
(16, 8, 13, 5),
(17, 8, 14, 6),
(18, 8, 15, 7),
(19, 9, 10, 1),
(20, 9, 13, 2),
(21, 10, 10, 1),
(22, 14, 10, 1),
(23, 11, 11, 1),
(24, 10, 10, 2),
(25, 10, 10, 3),
(26, 12, 10, 1),
(27, 12, 10, 2),
(28, 12, 10, 3),
(29, 14, 10, 1);
