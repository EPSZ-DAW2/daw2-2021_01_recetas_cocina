
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planificaciones`
--

CREATE TABLE IF NOT EXISTS `planificaciones` (
  `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `periodo` varchar(25) NOT NULL COMMENT 'Texto indicativo del Periodo de planificacion.',
  `usuario_id` int(12) UNSIGNED NOT NULL COMMENT 'Usuario que ha creado la planificacion o CERO si no existe (como si fuera NULL).',
  `notas` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `planificaciones`
--

TRUNCATE TABLE `planificaciones`;
--
-- Volcado de datos para la tabla `planificaciones`
--

INSERT INTO `planificaciones` (`id`, `nombre`, `periodo`, `usuario_id`, `notas`) VALUES
(8, 'Dieta hipocalorica', '15', 1, 'La dieta hipocalórica permite comer de forma equilibrada y saludable mediante el control de la ingesta de calorías, que varían dependiendo de nuestras características físicas y nuestro grado de actividad. En este tipo de dieta, se realizan cinco comidas al día y no se evita ningún grupo de alimentos, excepto aquellos como el azúcar y las grasas saturadas. Estos parámetros son aptos en una dieta para diabéticos, puesto que, además de repartir las comidas a lo largo del día,  limitan la cantidad de grasa, azúcares y sal que ingerimos, y permite consumir una gran variedad de frutas y verduras.'),
(9, 'Dieta por puntos', '15', 2, 'La dieta por puntos es una buena opción para aquellos que están aburridos de todas las dietas y quieren probar algo nuevo. En este tipo de dieta, también se consumen todos los grupos de alimentos de forma equilibrada y, para ello,  cuenta con una tabla de puntos que los clasifica según sus características. El objetivo de este plan de alimentación es no sobrepasar los puntos indicados al cabo del día. En esta dieta no hay alimentos prohibidos, pero siempre hay que evitar aquellos como bollería o embutidos grasos, porque su alta puntuación puede hacer que alcancemos la totalidad de los puntos, o los sobrepasemos, con sólo probarlos.'),
(10, 'Dieta paleo', '30', 3, 'La dieta paleo, también llamada dieta paleolítica, prácticamente se ha convertido en un estilo de vida. Consiste en volver a aquellos orígenes en los que la alimentación se basaba únicamente en lo que se cazaba y recolectaba. Por ello,  este tipo de dieta elimina los alimentos procesados y evita algunos grupos como cereales o lácteos, y basa la alimentación en carnes, pescados, frutas y verduras, que proporcionan un alto grado de energía. Aunque puede ser una buena opción, hay que encontrar el equilibrio en el consumo de estos productos, ya que un consumo excesivo de carne también puede ser perjudicial'),
(11, 'Dieta proteica', '21', 4, 'En la dieta proteica, se limita la alimentación a aquellos alimentos que son altos en proteínas, como la carne, el pescado y los derivados lácteos. Este tipo de dieta, que llega a excluir grupos de alimentos tan fundamentales como las frutas y las verduras, puede llegar a ocasionar graves problemas de salud. Algunas de las carencias más graves de esta dieta son la falta de hidratos de carbono y de fibra, imprescindibles para el buen funcionamiento de nuestro cuerpo. Esta restrictiva dieta posibilita perder kilos fácilmente a costa de nuestra salud y puede llegar a perjudicar gravemente nuestro metabolismo.'),
(12, 'Dieta detox', '28', 5, 'El término “detox” se ha convertido en una palabra que está en boca de todo el mundo, pero lo cierto es que este tipo de alimentación no puede sostenerse en el tiempo. Este tipo de dieta surge en los últimos años como una forma de depurar nuestro organismo, y se basa en el consumo exclusivo de líquidos durante, al menos, un día completo a la semana. Un consumo exclusivo de líquido no sólo no aporta la cantidad de energía necesaria para el funcionamiento del organismo, sino que puede provocar desequilibrios en componentes tan necesarios como el calcio, el potasio o el sodio.'),
(13, 'Dieta alcalina', '60', 6, 'También conocida como la dieta del pH y promocionada como la dieta “anticáncer”, este tipo de dieta es la última revolución entre los famosos.  La dieta alcalina promete depurar el organismo y, además, ser un fuerte protector contra posibles tumores, basándose en el consumo de alimentos que tienen supuestos efectos sobre la acidez de los fluidos de nuestro organismo. El punto a favor de esta dieta es que aboga por alimentos como cereales, frutas, verduras y legumbres, pero con una restricción tan amplia en el resto de alimentos que no es una opción saludable.'),
(14, 'Dieta de la sopa de tomate', '15', 7, 'Es la que siguen los enfermos del corazón del Secret Memorial Hospital de EEUU antes de una operación. Se trata de un plan de una semana que limpia impurezas y quema grasas muy rápido. La base de esta dieta de adelgazamiento es una sopa quemagrasas que se debe de comer todos los días y en la cantidad que se desee, porque apenas tiene calorías.');
