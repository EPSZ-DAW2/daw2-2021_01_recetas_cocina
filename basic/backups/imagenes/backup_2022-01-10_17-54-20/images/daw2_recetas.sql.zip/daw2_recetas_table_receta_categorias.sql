
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `receta_categorias`
--

CREATE TABLE IF NOT EXISTS `receta_categorias` (
  `id` int(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `receta_id` int(12) UNSIGNED NOT NULL,
  `categoria_id` int(12) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `receta_categorias_receta_id_idx` (`receta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `receta_categorias`
--

TRUNCATE TABLE `receta_categorias`;
--
-- Volcado de datos para la tabla `receta_categorias`
--

INSERT INTO `receta_categorias` (`id`, `receta_id`, `categoria_id`) VALUES
(1, 11, 1),
(2, 11, 3),
(3, 11, 4),
(4, 12, 4),
(5, 13, 2),
(6, 13, 4),
(7, 14, 3),
(8, 14, 4),
(9, 15, 4),
(10, 15, 3),
(11, 16, 1),
(12, 16, 3),
(13, 16, 4),
(14, 17, 3),
(15, 17, 4);
